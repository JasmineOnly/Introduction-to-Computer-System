/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_329(unsigned x)
{
    return x + 2445773128U;
}

void setval_140(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_498(unsigned x)
{
    return x + 3347662982U;
}

unsigned addval_313(unsigned x)
{
    return x + 613271384U;
}

unsigned addval_270(unsigned x)
{
    return x + 3243785293U;
}

void setval_234(unsigned *p)
{
    *p = 2425378973U;
}

unsigned addval_394(unsigned x)
{
    return x + 3284633928U;
}

void setval_390(unsigned *p)
{
    *p = 3251079496U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_308(unsigned x)
{
    return x + 3376991881U;
}

void setval_345(unsigned *p)
{
    *p = 2463205640U;
}

unsigned getval_470()
{
    return 3767093340U;
}

unsigned getval_350()
{
    return 3523792585U;
}

unsigned addval_286(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_429()
{
    return 3374895497U;
}

unsigned addval_243(unsigned x)
{
    return x + 3223376265U;
}

unsigned addval_328(unsigned x)
{
    return x + 3222848137U;
}

unsigned getval_400()
{
    return 3372794505U;
}

unsigned addval_454(unsigned x)
{
    return x + 3281047177U;
}

unsigned addval_306(unsigned x)
{
    return x + 3677933065U;
}

unsigned addval_130(unsigned x)
{
    return x + 3525889673U;
}

unsigned addval_295(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_121(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_159()
{
    return 3678981769U;
}

void setval_319(unsigned *p)
{
    *p = 2425537161U;
}

unsigned getval_488()
{
    return 2430638408U;
}

unsigned getval_280()
{
    return 650232457U;
}

unsigned addval_331(unsigned x)
{
    return x + 3286272330U;
}

unsigned getval_467()
{
    return 3372798347U;
}

unsigned getval_263()
{
    return 2462222797U;
}

unsigned addval_321(unsigned x)
{
    return x + 3871592077U;
}

void setval_126(unsigned *p)
{
    *p = 3376988809U;
}

void setval_442(unsigned *p)
{
    *p = 2425668233U;
}

unsigned getval_490()
{
    return 3531919785U;
}

unsigned getval_120()
{
    return 2430632264U;
}

void setval_108(unsigned *p)
{
    *p = 3674788249U;
}

unsigned addval_367(unsigned x)
{
    return x + 3383021961U;
}

unsigned getval_205()
{
    return 3281047177U;
}

unsigned getval_309()
{
    return 3286270280U;
}

unsigned getval_103()
{
    return 3526935177U;
}

unsigned addval_113(unsigned x)
{
    return x + 3375944073U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
